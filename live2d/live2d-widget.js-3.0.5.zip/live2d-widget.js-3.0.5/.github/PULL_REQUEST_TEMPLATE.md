Fix # , Re #.

Changes proposed in this pr:

此pr的改变：

- 

- 

- 

- [ ] I have alreday read instructions in [CONTRIBUTING](./CONTRIBUTING.md). 
我已仔细阅读[CONTRIBUTING](./CONTRIBUTING.md)中的相关内容。

- [ ] *NOT NECESSARY* I'm sure that this pr works properly in my testing environment.
*非必需* 提交的更改在我的测试环境运行正常

> Change the `[ ]` into `[x]` to show your acceptance.
将 `[ ]` 变为 `[x]` 来表示你接受了这些问题。


@EYHN @xiazeyu
